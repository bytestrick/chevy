--------------------------------------------
v44

updating godot autotiles with more content

--------------------------------------------
v43

add legacy tiles to the full version

--------------------------------------------
v42

fix version indexes in the README

--------------------------------------------
v41

fix version indexes in the README

-------------------------------------------
v40

fix atlas censor

-------------------------------------------
v39

add free content for rpgmaker users

--------------------------------------------
v38

Add godot autotiles

--------------------------------------------
v37

Add a golden spining coin

--------------------------------------------
v36

Add a golden coin in the icons2 png file

--------------------------------------------
v35

Add amethyst and orange and white gemstone variation in the icons2 png file

--------------------------------------------
v34

Add emerald and sapphire variation in the icons2 png file

--------------------------------------------
v33

Add a cristal in a new icons2 png file

--------------------------------------------
v32

Adding a new color variation to chests to complete the spritesheet

--------------------------------------------
v31

just a test update to see if the tweet publication works, test 3, no new content

--------------------------------------------
v30

just a test update to see if the tweet publication works, test 2, no new content

--------------------------------------------
v29

just a test update to see if the tweet publication works, no new content

--------------------------------------------
v28

Small highlight fixes on the heart and helm icons

--------------------------------------------
v27

Add doors file to the free version

--------------------------------------------
v26

Add chest and icons1 files to the free version

--------------------------------------------
v25

Add an helm to the icons1 png file

--------------------------------------------
v24

test scheduled update 3, no new content

--------------------------------------------
v23

test scheduled update 2, no new content

--------------------------------------------
v22

test scheduled update, no new content

--------------------------------------------
v21

Update the icons1.png with more hearts and a shield

--------------------------------------------
v20

Testing the devlog feature on the itchio page

--------------------------------------------
v19

Testing the devlog feature on the itchio page

--------------------------------------------
v18

Add the animated water and lava tiles

--------------------------------------------
v17

Fixing README file and version indexes

--------------------------------------------
v16

Adding icons1 but it is work in progress

--------------------------------------------
v15

Adding a README file
 
